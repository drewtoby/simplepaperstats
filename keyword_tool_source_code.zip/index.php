
<?php
//Below is our upload form; this can be integrated to a website (html). We only accept word and txt docs through it. Do we want to consider keeping the docs for research? Issue of security.
?>
</br>
<form action="bin/upload.php" method="post" enctype="multipart/form-data"> 
 <input type="file" name="myFile">
 <br>
 <center>
 <input type="submit" value="Upload">
</center>
 </form>