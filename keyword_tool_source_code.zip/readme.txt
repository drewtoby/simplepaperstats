Made by Drew Begg
Learn more at simplepaperstats.com
GPL 3.0.