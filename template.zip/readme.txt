An open-source minimalist template released under the GPL V. 3.0. Made by Drew Begg.
A special thanks to unsplash and iconmonstr for photos and icons respectively.
In order to avoid legal issues, I ask that you use these sites to find
your own images and icons. The template drop-down will work once you
do. Thanks for understanding.

Comments are included in both the HTML and CSS file. Another round of thanks for the 
following resources:

Responsive Header Image
http://www.tipue.com/blog/css-background-zoom/

Transparant Black Bar
https://www.w3schools.com/howto/howto_css_image_text.asp

Responsive Body Images
http://www.tipue.com/blog/css-background-zoom/

Transition Banner
http://www.tipue.com/blog/css-background-zoom/

Dropdown Button 
https://www.w3schools.com/howto/howto_css_dropdown.asp

Left and Right Bars
https://www.w3schools.com/howto/howto_css_dropdown.asp