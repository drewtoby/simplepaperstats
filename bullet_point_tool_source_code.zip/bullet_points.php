<?php

error_reporting(0); //remove error reporting 
@ini_set('display_errors', 0);

 if(isset($_POST['form'])){ // means submit clicked
	 
    //echo htmlspecialchars($_POST['form']); //echo the posted data
     
	 $input = $_POST['form']; //change into variable input
	 
	 $number = str_word_count ($input); //find number of words in text
     
	 $input_array = explode(" ", $input); //explode input into an array with each section being a word
    
	 $double_stop = 0;
   
     //for loop to remove caps
	 
	 for ($x=0; $x<$number; $x++)
	 {
		$input_array[$x] = strtolower ( $input_array[$x] ); //remove all caps
	 }
   
     //remove punctuation
   
     for ($x=0; $x<$number; $x++)
     {
		$input_array[$x] = chop($input_array[$x],"."); 
		$input_array[$x] = chop($input_array[$x],"."); 
		$input_array[$x] = chop($input_array[$x],"."); 
		$input_array[$x] = chop($input_array[$x],"?");
		$input_array[$x] = chop($input_array[$x],"!"); 
		$input_array[$x] = chop($input_array[$x],":"); 
		$input_array[$x] = chop($input_array[$x],";"); 
		$input_array[$x] = chop($input_array[$x],","); 
		$input_array[$x] = chop($input_array[$x],"-"); 
	 }
	 
 

    //find key words
 
    $nummy=0;
 
    for ($x=0; $x<$number; $x++)
    {
	 for ($y=0; $y<$number; $y++)
	 {
		if ($input_array[$x]==$input_array[$y] && $x!=$y)
		{
			$address[$nummy]=$y;
			$key_word[$nummy]=$input_array[$x];
			$nummy++;
		}
	 }
	}
 
   //$nummy is the number of repeated words, and $key_word is the array of key words. Their address in the original input array is address.
   
   //time to make the bullet points!
   
   
   if($nummy>0)
   {
   
   for ($z=1; $z<$nummy; $z=$z*5)
   {
	$word_number=$address[$z];
	
	if ($word_number-8>0 && $word_number+5<$nummy)
	{
		echo "* " . $input_array[$word_number-8] . " " . $input_array[$word_number-7] . " " . $input_array[$word_number-6] . " " . $input_array[$word_number-5] . " " . $input_array[$word_number-4] . " " . $input_array[$word_number-3] . " " . $input_array[$word_number-2] . " " . $input_array[$word_number-1] . " " . $input_array[$word_number] . " " . $input_array[$word_number+1] . " " . $input_array[$word_number+2] . " " . $input_array[$word_number+3] . " " . $input_array[$word_number+4] . " " . $input_array[$word_number+5] . "</br></br>";
	
	}
	
	if ($word_number-8<=0)
   {
	   echo "Error</br></br>";
	   $double_stop++;
   }
   
   if ($word_number+5>=$nummy && $double_stop=0)
   {
	   echo "Error</br></br>";
   }   


   }
   }
   
   else
   {
	   echo "Error</br></br>";
   }
   
   
   }
   
   else { //if submit does not work for whatever reason
	   echo "Error</br></br>";
   }
 
?>