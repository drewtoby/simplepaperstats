
					<FORM ACTION = "bullet_points.php" METHOD = "POST">
						 <textarea NAME="form" rows="11" cols="100">

							</textarea> 
									<li><INPUT TYPE = "submit" VALUE = "Turn this Block of Text into Bullet Points!"></li>
								</ul>

					</form>
